<?php
session_start();
$order_id = $_SESSION['order_id'];
$new_status="Paid";
//////////////////////////
//paystack webhook
////////////////////////////////
// please ensure to edit the webhook url on the dashboard to the destination of this file
// and the test secrete key below with the live secret key


date_default_timezone_set("Africa/Lagos");

if ((strtoupper($_SERVER['REQUEST_METHOD']) != 'POST' ) || !array_key_exists('HTTP_X_PAYSTACK_SIGNATURE', $_SERVER) ) {
    // only a post with paystack signature header gets our attention
    exit();
}

// Retrieve the request's body
$input = @file_get_contents("php://input");
define('PAYSTACK_SECRET_KEY','sk_test_1ac7d0d0da6987acef105fac3b6525a315f0b68c');
// sk_test_934ccf2edbe311a8ec0959b9e6123abb8e0dfee4
if(!$_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] || ($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] !== hash_hmac('sha512', $input, PAYSTACK_SECRET_KEY))){
  // silently forget this ever happened
  http_response_code(500);
  exit();
}

                //whether ip is from the share internet  
                 if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                            $ip = $_SERVER['HTTP_CLIENT_IP'];  
                    }  
                //whether ip is from the proxy  
                elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
                 }  
            //whether ip is from the remote address  
                else{  
                         $ip = $_SERVER['REMOTE_ADDR'];  
                 }  
    if(!( $ip =='52.214.14.220' ||   $ip =='52.49.173.169' ||  $ip=='52.31.139.75')){
        http_response_code(500);
        exit(); 
    }
 
file_put_contents("paystack_log.txt", $input);

//$event = json_decode(file_get_contents("php://input"),true);

$event = json_decode($input , true);

 $date=date("j/m/Y") ;
$time=date("h:i:s A") ;
// $date=$date." ".$time;

$date = date("m/d/Y h:i A");
   $final = strtotime($date);
   $created_at = date("Y-m-d H:i:s", $final);

$trans_ref = $event['event'];
$amount = $event['data']['amount'];
$email = $event['data']['customer']['email'];
$reference = $event['data']['reference'];
$dates = $event['data']['paid_at'];
$status= $event['data']['status'];
$amount_paid= $amount/100;
$actual_amount= $event['data']['metadata']['cart_id'];

$value= $event['data']['metadata']['custom_fields']['display_name'];

$actual_amount = $res["eventData"]["paymentDescription"];


//Database
include('database/connection.php');
// include('public/database/config.php');

// $transaction_details='{
//     "amount": "'.$actual_amount.'",
//     "type": "Funding",
//     "Means": "Account Transfer"
// }';

//file_put_contents("paystack_log.txt", $input);

$sql="SELECT * from orders WHERE order_id =?";
$query = $conn->prepare($sql);
$query->execute([$order_id]);
$row=$query->fetch(PDO::FETCH_ASSOC);
if($query->rowCount() > 0)
{
    $order_status = $row['order_status'];
    $phone = $row['user_phone'];
    $user_id = $row['user_id'];
    
}
else{
            http_response_code(500);
            exit();
          }

          $query1="SELECT * FROM payments where transaction_id=?";
          $query = $conn->prepare($query1);
          $query->execute([$reference]);
          $row=$query->fetch(PDO::FETCH_ASSOC);
          if($query->rowCount() > 0)
          {
            
          http_response_code(500);
          exit();
          
        }else{

            // $sql="SELECT * FROM users where dob=?";
            // $query = $dbh->prepare($sql);
            // $query->execute([$reference]);
            // $row=$query->fetch(PDO::FETCH_ASSOC);
            // if($query->rowCount() > 0)
            // {
            // http_response_code(500);
            // exit;
            // }
           
           try{

           $str="INSERT INTO transaction (phone,email,amount,transaction_id,date) VALUES (?,?,?,?,?)";
           $query = $conn->prepare($str);
           $query->execute([$phone,$email, $actual_amount, $reference,$created_at]);


           $sql = "UPDATE orders SET order_status =? WHERE order_id =?";
           $query = $conn->prepare($sql);
           $query->execute([$new_status,$order_id]);

           http_response_code(200); 
        } catch(PDOException $e) {
           header('Content-type: application/json');
           http_response_code(500);
             // $response = array();
        //      $response= array(
        //          'status'=> false,
        //          'message'=> $e,
        //   );		        
        //  echo json_encode($response); 
         exit();
        }

    }

// $result = mysqli_query($dbh, $str);

//referer
// if($actual_amount < 500){
// http_response_code(200);
// exit;
// }else{
// include('app/services/referral.php');

// http_response_code(200);
//             exit;
// }
// //referer end
  
//             http_response_code(200); // PHP 5.4 or greater
//             exit;
      



?>