<?php 

    include("partials/header.php"); 

    include('database/connection.php');

$stmt = $conn->prepare("SELECT * FROM products");

$stmt->execute();

$shop = $stmt ->get_result();


?>





<!-- Shop -->
<section id="featured" class="my-5 py-5">
    <div class="container  mt-5 py-5">
        <h3>Our Products</h3>
        <hr >
        <p>Here you can check out our products</p>
    </div>
    
    <div class="row mx-auto container-fluid pt-5">
    <?php while ($row = $shop->fetch_assoc()) { ?>
        <div class="products text-center col-lg-3 col-md-4 col-sm-12">
        
            <img onclick="window.location.href='single_product.php'" class="img-fluid" src="assets/imgs/<?php echo $row['product_image']; ?>">
            <div class="star">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
            </div>
            <h5 class="p-name"><?php echo $row['product_name']; ?></h5>
            <h4 class="p-price">₦<?php echo $row['product_price']; ?></h4>
            <a href="<?php echo "single_product.php?product_id=".$row['product_id']; ?>"> <button class="buy-btn">Buy Now</button></a>
            
        </div>
        <?php } ?>
    </div>
    


   
        <!-- PAGINATION -->
        <nav aria-label="Page navigation example">
            <ul class="pagination mt-5">
                <li class="page-item"><a href="#" class="page-link">Previous</a></li>
                <li class="page-item"><a href="#" class="page-link">1</a></li>
                <li class="page-item"><a href="#" class="page-link">2</a></li>
                <li class="page-item"><a href="#" class="page-link">3</a></li>
                <li class="page-item"><a href="#" class="page-link">Next</a></li>
            </ul>

        </nav>


    </div>
</section> 





<?php include("partials/footer.php"); ?>