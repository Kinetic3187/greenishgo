<?php
$reference=ref();

echo $reference;
?>