<?php 

  include('partials/header.php'); 

  if (isset($_POST['order_pay_btn'])) {
    
    $order_status = $_POST['order_status'];
    $order_total_price = $_POST['order_total_price'] + 300;
    $user_email = $_SESSION['user_email'];
    $order_id = $_SESSION['order_id'];
    $user_id  = $_SESSION['user_id'];



  }





?>




<!-- Payment -->
<section class="my-5 py-5">
    <div class="container text-centre mt-3 pt-5">
        <h2 class="form-weight-bold mx-auto text-center">Payment</h2>
        <hr class="mx-auto">
    </div>
    <div class="mx-auto container text-centre">
        <!-- <form action="" method="POST" id="paymentForm"> -->
          <div class="form-group checkout-sm-element">
             
            <div class="form-group checkout-btn-container text-center">
               

              <?php if (isset($_POST['order_status']) && $_POST['order_status'] == "not paid"){ ?>  
                <?php $amount = strval($_SESSION['total']+300); ?>
                          <?php $order_id = $_SESSION['order_id']; ?>
                          <p>Total amount: ₦<?php echo $_SESSION['total']+300; ?></p>
                         
                          <form action="payment_api.php"  method="POST"> 
                          <input type="hidden" name="order_status" value="<?php echo $order_status; ?>"> 
                          <!-- <input type="hidden" name="user_email" value="<?php echo $user_email; ?>"> 
                          <input type="hidden" name="amount" value="<?php echo $amount; ?>">  -->
                          <button type="submit" name="pay_now" id="pay-now" title="Pay now">Pay now</button>
                          </form>

                <?php }else if(isset($_SESSION['total']) && $_SESSION['total'] != 0){ ?>
                          <?php $amount = strval($_SESSION['total']+300); ?>
                          <?php $order_id = $_SESSION['order_id']; ?>
                          <p>Total amount: ₦<?php echo $_SESSION['total']+300; ?></p>
                         
                          <form action="payment_api.php"  method="POST"> 
                          <input type="hidden" name="order_status" value="<?php echo $order_status; ?>"> 
                          <!-- <input type="hidden" name="user_email" value="<?php echo $user_email; ?>"> 
                          <input type="hidden" name="amount" value="<?php echo $amount; ?>">  -->
                          <button type="submit" name="pay_now" id="pay-now" title="Pay now">Pay now</button>
                          </form>

                <?php }else {?>
                  
                        <p> You don't have any order</P>

                <?php } ?>
                       
              
              

            </div>
            
        <!-- </form> -->
      </div>
    </div>
</section>



 

    

<?php include('partials/footer.php'); ?>