<?php 
  session_start();
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS LINKS -->
    <link rel="stylesheet" href="assets/CSS/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- /*<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
   
    <!-- font awesome link -->
  <script src="https://kit.fontawesome.com/e056f5cd61.js" crossorigin="anonymous"></script>

</head>
<body>
    
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 fixed-top">
        <div class="container">
          <a href="index.php"><img class="logo" src="assets/imgs/glogo.jpg" ></a> 
          <h2 class="brand">Greenish</h2>
          <button class="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse nav-buttons" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="shop.php">Shop</a>
              </li>
              <!-- <li class="nav-item">
                <a class="nav-link" href="#">Blog</a>
              </li> -->
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact Us!</a>
              </li>
              <li class="nav-item">
                <a href="cart.php"><i class="fa-solid fa-cart-shopping" >
                  <?php if(isset($_SESSION['quantity']) && $_SESSION['quantity'] != 0) {?>
                          <span class="cart-quantity"> <?php echo $_SESSION['quantity']; ?> </span>
                    <?php } ?>
                 </i>
                </a>
                 <a href="register.php"><i class="fa-solid fa-user" ></i></a>
              </li>
              
              
              
            </ul>
           
          </div>
        </div>
      </nav>


      <style>
    .products img{
        width: 100%;
        height: auto;
        box-sizing: border-box;
        object-fit: cover;                                                                                                                                                                                                                                                                                                                                                                                                                               
    }

    .pagination a{
        color: coral;
    }

    .pagination li:hover a{
        color: #fff;
        background-color: coral;
    }



</style>


    <style>
    .products img{
        width: 100%;
        height: auto;
        box-sizing: border-box;
        object-fit: cover;                                                                                                                                                                                                                                                                                                                                                                                                                               
    }

    .pagination a{
        color: coral;
    }

    .pagination li:hover a{
        color: #fff;
        background-color: coral;
    }



</style>





































