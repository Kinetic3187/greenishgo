<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM products WHERE product_category= 'fruits' LIMIT 4");

$stmt->execute();

$fruits_products = $stmt ->get_result();






?>