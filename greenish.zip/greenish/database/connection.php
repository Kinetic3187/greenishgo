<?php

$conn = new mysqli("localhost","root","","greenish")
or die("Could not connect to database");



?>