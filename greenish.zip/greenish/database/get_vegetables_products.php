<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM products WHERE product_category= 'Vegetables' LIMIT 4");

$stmt->execute();

$vegetables_products = $stmt ->get_result();






?>