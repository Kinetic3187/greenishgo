<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM products WHERE product_category= 'foodstuffs' LIMIT 4");

$stmt->execute();

$foodstuffs_products = $stmt ->get_result();






?>