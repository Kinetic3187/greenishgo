<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GreenishGO</title>
    <link rel="stylesheet" href="Greenish/style.css">
    <link rel="stylesheet" href="../CSS/all.css">

      <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/e056f5cd61.js" crossorigin="anonymous"></script>
        
      <!-- GOOGLE FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@500&family=Poppins:wght@300&display=swap" rel="stylesheet">

        <!-- FAVICON GENERATOR -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">

       <!-- BOOTSRAP -->
       <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous"> -->

</head>
<body>
    
    <nav class="navigation">
        
        <div class="logo-head">
            <img src="image/leaf.svg" alt="">
            <h5><span>Green</span>ishGO</h5>
        </div>
        <!-- <button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button> -->
        <div class="nav-link">
            <i class="fa-solid fa-xmark closebtn"></i>
            <ul>
                <li><a href="home.php">Shop</a></li>
                <li><a href="#">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <i class="fa-solid fa-bars menubtn"></i>
    </nav>   

    <section id="home" class="hero_page">
        <div class="text_block">
            <h1>New fre<span>sh</span></h1>
            <h3>fruits and vegetables</h3>
            <a href="#" class="btn-light">order now</a>
        </div>
        <div class="blur"></div>
        <svg xmlns="http://www.w3.org/2000/svg" width="972.143" height="810" viewBox="0 0 972.143 810" class="Path_1">
            <path id="Path_1" data-name="Path 1" d="M515.231,132.2c242.7-112.732,438.912,67.58,438.912,316.31S707.211,898.878,455.594,898.878,0,697.243,0,448.513,272.528,244.935,515.231,132.2Z" transform="translate(9 -88.87)" fill="#6fae6d" opacity="0.34"/>
          </svg>
          
    </section>
    <section></section>
    <section></section>
    <section></section>
</body>
<script src="Greenish/js/scrollreveal.min.js"></script>
<script>
    const header = document.querySelector("nav");

    window.addEventListener('scroll', ()=> {
        header.classList.toggle('sticky', window.scrollY > 0);
    });


    const menuBtn = document.querySelector(".menubtn");
    const closeBtn = document.querySelector(".closebtn");
    const navigation = document.querySelector(".nav-link");

    menuBtn.addEventListener('click', ()=> {
        navigation.classList.toggle('active');
    })
    closeBtn.addEventListener('click', ()=> {
        navigation.classList.remove('active');
    })

    window.onscroll = () => {
        navigation.classList.remove('active');
    }

    const sr = ScrollReveal ({
        distance: '25 px',
        duration: 2500,
        reset: true
    })

    sr.reveal('.text_block', {delay:190, origin:'top'})


</script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>


</html>