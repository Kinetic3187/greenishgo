<?php 

include('partials/header.php'); 
include('database/connection.php');

    if (!isset($_SESSION['logged_in'])) {
        header("LOCATION:login.php");
    }

    if (isset($_GET['logout'])) {
       if (isset($_SESSION['logged_in'])) {
        unset($_SESSION['logged_in']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        unset($_SESSION['user_id']);
        header("LOCATION:login.php");
        exit;
       }
    }

if (isset($_POST['change_password'])) {


    $password = $_POST['password'];
    $Cpassword = $_POST['Cpassword'];
    $user_email = $_SESSION['user_email'];
    
            if ($password != $Cpassword) {
                header("LOCATION:account.php?error=Passwords didn't match");
            }else if (strlen($password < 6)) {
                header("LOCATION:account.php?error=Password must be at least 6 characters");
            }else {
                
               $stmt = $conn -> prepare("UPDATE users SET user_password=? WHERE user_email=? ");
               $stmt -> bind_param('ss', md5($password), $user_email);

                if($stmt->execute()){
                    header("LOCATION: account.php?message=Password Changed Successfully");
                }else {
                    header("LOCATION: account.php?error=Password couldn't be changed, Try again later.");
                }

            }





}

if (isset($_SESSION['logged_in'])) {
    
    $user_id = $_SESSION['user_id'];
    

    $stmt = $conn->prepare("SELECT * FROM orders WHERE user_id=? ");

    $stmt->bind_param('i',$user_id);

    $stmt->execute();


    $orders = $stmt->get_result();
}


?>
     





<!-- Account -->
<section class="ny-5 py-5">
    <div class="row container mx-auto">

        <?php if(isset($_GET['payment_message'])) {?>
        <p class="mt-5 text-center" style="color:green;"><?php echo $_GET['payment_message']; ?></p>
        <?php } ?>

        <div class="text-center mt-3 pt-5 col-lg-6 col-md-12 col-sm-12">
        <p class="text-center" style="color:green;"><?php if (isset($_GET['register_success'])) { echo $_GET['register_success']; }?></p>
        <p class="text-center" style="color:green;"><?php if (isset($_GET['login_success'])) { echo $_GET['login_success']; }?></p>
            <h3 class="font-weight-bold">Account Info</h3>
            <hr class="mx-auto">
            <div class="account-info">
                <p>Name:   <span><?php if (isset($_SESSION['user_name'])) { echo $_SESSION['user_name']; } ?></span></p>
                <p>Email:  <span><?php if (isset($_SESSION['user_email'])) { echo $_SESSION['user_email']; } ?></span></p>
                <p><a href="#orders" id="order-btn">Your Orders</a></p>
                <p><a href="account.php?logout=1" class="logout-btn">Logout</a></p>
            </div>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12">
            <form action="account.php" method="POST" id="account-form">
                <p class="text-center" style="color:red;"><?php if (isset($_GET['error'])) { echo $_GET['error']; }?></p>
                <p class="text-center" style="color:green;"><?php if (isset($_GET['message'])) { echo $_GET['message']; }?></p>
                <h3>Change Password</h3>
                <hr class="mx-auto">
                <div class="form-group">
                    <label >Password</label>
                    <input type="password" class="form-control" id="account-password" name="password">
                </div>
                <div class="form-group">
                    <label >Confirm Password</label>
                    <input type="password" class="form-control" id="account-password-confirm" name="Cpassword">
                </div>
                <div class="form-group">
                    <input type="submit" name="change_password" value="Change Password" class="btn" id="change-pass-btn">
                </div>

            </form>
        </div>

    </div>

</section>



     <!-- Order -->
     <section id="orders" class="orders container my-5 py-2">
        <div class="container mt-2">
            <h2 class="font-weight-bolde text-center">Your Cart</h2>
            <hr class="mx-auto">
        </div>
        <table class="mt-5 pt-5">
            <tr>
                <th>Order id</th>
                <th>Order cost</th>
                <th>Order status</th>
                <th>Order Date</th>
                <th>Order details</th>
            </tr>

            <?php  while($row = $orders->fetch_assoc()){?>
           
                    <tr>
                    <td>
                        <!-- <div class="product-info"> -->
                            <!-- <img src="assets/imgs/featured1.jpeg" > -->
                            
                        <div>
                            <p class="mt-3"><?php echo $row['order_id']; ?></p>
                        </div> 
                    </td>
                    <td>
                        <span><?php echo $row['order_cost']; ?></span>
                    </td>
                    <td>
                        <span><?php echo $row['order_status']; ?></span>
                    </td>
                    <td>
                        <span><?php echo $row['order_date']; ?></span>
                    </td>
                    <td>
                        <form action="order_details.php" method="POST">
                            <input type="hidden" name="order_status" value="<?php echo $row['order_status']; ?>">
                            <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                            <input class="btn orders-details-btn" name="order_details" type="submit" value="details">
                        </form>
                      
                    </td>
                     </tr> 
            <?php } ?>
               
            </table>

           
        
       </section>




       <?php include('partials/footer.php'); ?>