<?php include('partials/header.php'); ?>

      <!-- Home -->
      <section id="home">
<!-- <div class="container">
              <h5>NEW ARRIVAL</h5>
              <h1> <span>Best Prices </span>This Season </h1>
              <p>Eshop offers the best products for the most affordable prices </p>
              <button>Shop Now</button>
          </div> -->
      </section>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
      <!-- Brand -->
      <!-- <section id="brand" class="container">
          <div class="row">
              <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand1.jpeg" >
              <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand2.jpeg" >
              <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand3.jpeg" >
              <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand4.jpeg" >

        </div>
      </section> -->

      <!-- New -->
      <section id="new" class="w-100">
          <div class="row m-0 p-0">
              <!-- One -->
              <div class="one col-lg-4 col-md-12 col-sm-12 p-0">
                <img class="img-fluid" src="assets/imgs/1.jpeg" >
                <div class="details">
                    <h2>Fruits</h2>
                    <button class="text-uppercase">Shop Now</button>
                </div>
              </div>
              <!-- Two -->
              <div class="one col-lg-4 col-md-12 col-sm-12 p-0">
                <img class="img-fluid" src="assets/imgs/2.jpeg" >
                <div class="details">
                    <h2>Vegetables</h2>
                    <button class="text-uppercase">Shop Now</button>
                </div>
              </div>
              <!-- Three -->
              <div class="one col-lg-4 col-md-12 col-sm-12 p-0">
                <img class="img-fluid" src="assets/imgs/3.jpeg" >
                <div class="details">
                    <h2>Foodstuffs</h2>
                    <button class="text-uppercase">Shop Now</button>
                </div>
              </div>

          </div>
      </section>

       <!-- Featured -->
        <section id="featured" class="my-5 pb-5">
            <div class="container text-center mt-5 py-5">
                <h3>Our Featured</h3>
                <hr class="mx-auto">
                <p>Here you can check our featured products</p>
            </div>
            <div class="row mx-auto container-fluid">

            <?php include('database/get_featured_products.php'); ?>
            <?php while ($row= $featured_products->fetch_assoc()) { ?>
                
            
                <div class="products text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid" src="assets/imgs/<?php echo $row['product_image'] ?>">
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h5 class="p-name"> <?php echo $row['product_name'] ?> </h5>
                    <h4 class="p-price">₦<?php echo $row['product_price'] ?></h4>
                    <a href="single_product.php?product_id=<?php echo $row['product_id']; ?>"><button class="buy-btn">Buy Now</button></a>
                </div>
            
            
              <?php } ?>
              </div>
        </section> 

        
        
        <!-- Banner -->
        <section id="banner" class="my-5 py-5">
            <!-- <div class="container">
                <h4>MID SEASON's SALE</h4>
                <h1>Autumn Collection <br>UP to 30% OFF</h1>
                <button class="text-uppercase">Shop Now</button>
            </div> -->
        </section>
       <!-- Fruits -->
        <section id="featured" class="my-5 pb-5">
            <div class="container text-center mt-5 py-5">
                <h3>Fruits</h3>
                <hr class="mx-auto">
                <p>Here you can check out the available fruits</p>
            </div>
            <div class="row mx-auto container-fluid">

            <?php include('database/get_fruits_products.php'); ?>

            <?php while ($row= $fruits_products->fetch_assoc()) { ?>

                <div class="products text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid" src="assets/imgs/<?php echo $row['product_image'] ?>">
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h5 class="p-name"><?php echo $row['product_name'] ?></h5>
                    <h4 class="p-price">₦<?php echo $row['product_price'] ?></h4>
                    <a href="single_product.php?product_id= <?php echo $row['product_id']; ?>"><button class="buy-btn">Buy Now</button></a>
                    
                </div>
                <?php } ?>
                </div>
        </section> 

        <!-- Vegetables -->
        <section id="featured" class="my-5 pb-5">
            <div class="container text-center mt-5 py-5">
                <h3>Vegetables</h3>
                <hr class="mx-auto">
                <p>Here you can check out our nice looking Vegetables</p>
            </div>
            <div class="row mx-auto container-fluid">

            <?php include('database/get_vegetables_products.php'); ?>

            <?php while ($row= $vegetables_products->fetch_assoc()) { ?>

            <div class="products text-center col-lg-3 col-md-4 col-sm-12">
            <img class="img-fluid" src="assets/imgs/<?php echo $row['product_image'] ?>">
            <div class="star">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
            </div>
            <h5 class="p-name"><?php echo $row['product_name'] ?></h5>
            <h4 class="p-price">₦<?php echo $row['product_price'] ?></h4>
            <a href="single_product.php?product_id= <?php echo $row['product_id']; ?>"><button class="buy-btn">Buy Now</button></a>
            
            </div>
            <?php } ?>
            </div>
        </section> 
        <!-- Food Stuffs -->
        <section id="featured" class="my-5 pb-5">
            <div class="container text-center mt-5 py-5">
                <h3>Foodstuffs</h3>
                <hr class="mx-auto">
                <p>Check out our available foodstuffs</p>
            </div>
            <div class="row mx-auto container-fluid">

            <?php include('database/get_foodstuffs_products.php'); ?>

            <?php while ($row= $foodstuffs_products->fetch_assoc()) { ?>

            <div class="products text-center col-lg-3 col-md-4 col-sm-12">
            <img class="img-fluid" src="assets/imgs/<?php echo $row['product_image'] ?>">
            <div class="star">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
            </div>
            <h5 class="p-name"><?php echo $row['product_name'] ?></h5>
            <h4 class="p-price">₦<?php echo $row['product_price'] ?></h4>
            <a href="single_product.php?product_id= <?php echo $row['product_id']; ?>"><button class="buy-btn">Buy Now</button></a>
            
            </div>
            <?php } ?>
            </div>
           
        </section> 

        <?php include('partials/footer.php'); ?>
      