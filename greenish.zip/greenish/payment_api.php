<?php
session_start();
include('database/connection.php');
$order_id = $_SESSION['order_id'];
    $user_id = $_SESSION['user_id'];

if (isset($_POST['pay_now'])) {
    $user_email = $_SESSION['user_email'];
    $total = ($_SESSION['total'] + 300) * 100;
    $order_status = $_POST['order_status'];
    
  $url = "https://api.paystack.co/transaction/initialize";

  $fields = [
    'email' => "$user_email",
    'amount' => "$total"
  ];

  $fields_string = http_build_query($fields);

  //open connection
  $ch = curl_init();
  
  //set the url, number of POST vars, POST data
  curl_setopt($ch,CURLOPT_URL, $url);
  curl_setopt($ch,CURLOPT_POST, true);
  curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Authorization: Bearer sk_test_1ac7d0d0da6987acef105fac3b6525a315f0b68c",
    "Cache-Control: no-cache",
  ));
  
  //So that curl_exec returns the contents of the cURL; rather than echoing it
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 
  
  //execute post
  $result = curl_exec($ch);
  // echo $result;
  $outcome = json_decode($result, true);
  $status = $outcome['status'];
  $message = $outcome['message'];
  $access_code = $outcome['data']['access_code'];
  $refrence_id = $outcome['data']['reference'];
  $authorization_url = $outcome['data']['authorization_url'];
  $amount_paid = $total/100;

      if ($status == 1 && $message == "Authorization URL created" ) {
        
        $str="INSERT INTO payments (order_id,user_id,amount,transaction_id) VALUES (?,?,?,?)";
        $query = $conn->prepare($str);
        $query->execute([$order_id,$user_id, $amount_paid, $refrence_id]);

      }
  
    # code...
     header("LOCATION: $authorization_url");
   
  }




 

  


?>